from ks2ool.io import get_waveforms
